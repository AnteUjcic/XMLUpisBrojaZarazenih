﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upsi_Broja_zarazenih
{
    internal class Selo
    {
        string imeSela;
        int IDSela;
        int BrojStanovnika;



        public Selo(string imeSela, int iDSela, int brojStanovnika)
        {
            this.imeSela = imeSela;
            IDSela = iDSela;
            BrojStanovnika = brojStanovnika;
        }

        public string ImeSela { get => imeSela; set => imeSela = value; }
        public int IDSela1 { get => IDSela; set => IDSela = value; }
        public int BrojStanovnika1 { get => BrojStanovnika; set => BrojStanovnika = value; }
    }
}
