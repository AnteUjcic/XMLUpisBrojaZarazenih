﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upsi_Broja_zarazenih
{
    internal class Zarazeni
    {
        string ime;
        string prezime;
        int oIB;
        DateTime datumUpisa;
        int brojZarazenih;

        public Zarazeni(string ime, string prezime, int oIB, DateTime datumUpisa, int brojZarazenih)
        {
            this.ime = ime;
            this.prezime = prezime;
            this.oIB = oIB;
            this.datumUpisa = datumUpisa;
            this.brojZarazenih = brojZarazenih;
        }

        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public int OIB { get => oIB; set => oIB = value; }
        public DateTime DatumUpisa { get => datumUpisa; set => datumUpisa = value; }
        public int BrojZarazenih { get => brojZarazenih; set => brojZarazenih = value; }
    }
}
